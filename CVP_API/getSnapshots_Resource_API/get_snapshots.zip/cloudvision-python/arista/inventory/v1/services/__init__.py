# Copyright (c) 2020 Arista Networks, Inc.  All rights reserved.

# pylint: disable=wildcard-import
from arista.inventory.v1.services.gen_pb2 import *
# pylint: disable=wildcard-import
from arista.inventory.v1.services.gen_pb2_grpc import *
